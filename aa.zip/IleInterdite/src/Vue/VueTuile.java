/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Ile_interdite.Etat;
import Ile_interdite.Tuile;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author belhadja
 */
public class VueTuile extends JPanel {
    
    private int x;
    private int y;
    private String nom ;
    private BufferedImage image;
    public VueTuile(Tuile tu) {
        this.x = tu.getX();
        this.y = tu.getY();
        this.nom = tu.getNom();
        this.setImage();
        if( tu.getEtat().equals(Etat.Coulé)||tu.getEtat().equals(Etat.Inexistant)){
            this.setBackground(Color.BLUE);
        }else if (tu.getEtat().equals(Etat.Emergé)){
            this.setBackground(Color.GREEN);
            this.add(new JLabel(x+","+y));
            this.add(new JLabel(nom));
        }
        
        

        this.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println(tu);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                if( !tu.getEtat().equals(Etat.Coulé) && !tu.getEtat().equals(Etat.Inexistant)){
                    setBackground(Color.RED);
                }               
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if( tu.getEtat().equals(Etat.Coulé)||tu.getEtat().equals(Etat.Inexistant)){
                    setBackground(Color.BLUE);
                }else if (tu.getEtat().equals(Etat.Emergé)){
                    setBackground(Color.GREEN);
                }
            }
        });
        
    }//FIN CONSTRUCTEUR
    
    
    public void setImage(){
        
    }
    
    
    
    
    
    
}


