package Ile_interdite;



public class Explorateur extends Aventurier {

	public void deplacementPossible(Grille g) {
		throw new UnsupportedOperationException();
	}
}