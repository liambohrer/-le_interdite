package Ile_interdite;
public class Navigateur extends Aventurier {
}