/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ile_interdite;

import Vue.VueAventurier;
import Vue.VueGrille;
import java.awt.BorderLayout;
import java.awt.Color;
import static java.awt.SystemColor.window;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author bohrerl
 */
public class IHM {
        private JFrame window ;
        private VueGrille vueGrille;
        private VueAventurier vueAventurier;

    public IHM(Grille grille) {
        this.window = new JFrame();
        window.setSize(800, 600);
        window.setTitle("hey");
        JPanel panel = new JPanel(new BorderLayout());
        
        vueGrille = new VueGrille(grille);
        vueAventurier = new VueAventurier("hey", "Aventurier", Color.blue);
        panel.add(this.vueGrille,BorderLayout.CENTER);
        panel.add(this.vueAventurier,BorderLayout.SOUTH);
        window.add(panel);
        window.setVisible(true);
        
    }

    public VueGrille getVueGrille() {
        return this.vueGrille;
    }

    public VueAventurier getVueAventurier() {
        return this.vueAventurier;
    }
        
    
        
        
        
    
}
