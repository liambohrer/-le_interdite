package Ile_interdite;
public class Ingénieur extends Aventurier {
}