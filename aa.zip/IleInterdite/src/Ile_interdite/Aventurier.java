package Ile_interdite;


public abstract class Aventurier {
	private String nomJ;
	private Tuile position;

	public void deplacementPossible(Grille g) {
		g.getGrille()
	}

	public void AssechementPossible(Grille g) {
		
	}

	public void getTuile() {
            
	}

	public void chercherTuile(String nom) {
		
	}

	public void addNomTuile(Tuile tu) {
		
	}
}