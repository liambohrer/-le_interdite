/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ile_interdite;

import Ile_interdite.Utils.Pion;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author bohrerl
 */
public class Grille {
   

    private ArrayList<Tuile> tuilesDansLeDesordre; 
    private HashMap<Integer,Tuile>  grille;
    // La clé est la position . Exemple : Tuile en (2,3) a pour clé 23
    
    Grille(){
        tuilesDansLeDesordre =  new ArrayList<Tuile>();
        grille = new HashMap<>();
        
        tuilesDansLeDesordre.add(new Tuile("Le Pont des Abimes"));
        tuilesDansLeDesordre.add(new Tuile("La Porte de Bronze"));
        tuilesDansLeDesordre.add(new Tuile("La Caverne des Ombres"));
        tuilesDansLeDesordre.add(new Tuile("La Porte de Fer"));
        tuilesDansLeDesordre.add(new Tuile("La Porte d’Or"));
        tuilesDansLeDesordre.add(new Tuile("Les Falaises de l’Oubli"));
        tuilesDansLeDesordre.add(new Tuile("Le Palais de Corail"));
        tuilesDansLeDesordre.add(new Tuile("La Porte d’Argent"));
        tuilesDansLeDesordre.add(new Tuile("Les Dunes de l’Illusion"));
        tuilesDansLeDesordre.add(new Tuile("Heliport"));
        tuilesDansLeDesordre.add(new Tuile("La Porte de Cuivre"));
        tuilesDansLeDesordre.add(new Tuile("Le Jardin des Hurlements"));
        tuilesDansLeDesordre.add(new Tuile("La Foret Pourpre"));
        tuilesDansLeDesordre.add(new Tuile("Le Lagon Perdu"));
        tuilesDansLeDesordre.add(new Tuile("Le Marais Brumeux"));
        tuilesDansLeDesordre.add(new Tuile("Observatoire"));
        tuilesDansLeDesordre.add(new Tuile("Le Rocher Fantome"));
        tuilesDansLeDesordre.add(new Tuile("La Caverne du Brasier"));
        tuilesDansLeDesordre.add(new Tuile("Le Temple du Soleil"));
        tuilesDansLeDesordre.add(new Tuile("Le Temple de La Lune"));
        tuilesDansLeDesordre.add(new Tuile("Le Palais des Marees"));
        tuilesDansLeDesordre.add(new Tuile("Le Val du Crepuscule"));
        tuilesDansLeDesordre.add(new Tuile("La Tour du Guet"));
        tuilesDansLeDesordre.add(new Tuile("Le Jardin des Murmures"));
        
        Collections.shuffle(tuilesDansLeDesordre);
        int numeroTuile = 0;
        for ( int i=1; i<=6;i++ ){
            for (int j=1; j<=6;j++){
                    if ((i==1 && j==1)||    // COORDONNÉES DES ANGLES
                    (i==1 && j==2)||
                    (i==2 && j==1)||
                    (i==1 && j==5)||
                    (i==1 && j==6)||
                    (i==2 && j==6)||
                    (i==5 && j==1)||
                    (i==6 && j==1)||
                    (i==6 && j==2)||
                    (i==5 && j==6)||
                    (i==6 && j==6)||
                    (i==6 && j==5)){
                    Tuile tuile = new Tuile("Vide",Etat.Inexistant);
                    tuile.setX(i);
                    tuile.setY(j);
                    grille.put(10*i+j,tuile);
                    
                }
                else{                   
                    Tuile tuile = tuilesDansLeDesordre.get(numeroTuile);
                    tuile.setX(i);
                    tuile.setY(j);
                    tuile.setEtat(Etat.Emergé);
                    
                    grille.put(10*i+j,tuile );
                    numeroTuile++;
                }

                
                
            }
                
        }
        
    }

    public HashMap<Integer, Tuile> getGrille() {
        return grille;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
