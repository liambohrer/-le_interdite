/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ile_interdite;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author belhadja
 */
public class VueGrille extends JPanel{

    public VueGrille(Grille g) {
        this.setLayout(new GridLayout(6, 6));
        for ( int i=1; i<=6;i++ ){
            for (int j=1; j<=6;j++){
                this.add(new VueTuile(g.getGrille().get(10*i+j)));
            }
        }
            

    }
    
    
    
}
