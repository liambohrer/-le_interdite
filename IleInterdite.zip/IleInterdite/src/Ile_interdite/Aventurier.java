package Ile_interdite;


public abstract class Aventurier {
	private String nomJ;
	public Tuile position;

	public void deplacementPossible(Grille g) {
		throw new UnsupportedOperationException();
	}

	public void AssechementPossible(Grille g) {
		throw new UnsupportedOperationException();
	}

	public void getTuile() {
		throw new UnsupportedOperationException();
	}

	public void chercherTuile(String nom) {
		throw new UnsupportedOperationException();
	}

	public void addNomTuile(Tuile tu) {
		throw new UnsupportedOperationException();
	}
}