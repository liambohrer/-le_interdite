package Ile_interdite;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import static javax.swing.SwingConstants.CENTER;
import javax.swing.border.MatteBorder;
import Ile_interdite.Utils;
import Ile_interdite.Utils.Pion; 

 
public class VueAventurier extends JPanel {
     
    private final JPanel panelBoutons ;
    //private final JPanel panelCentre ;
    private final JPanel panelAventurier;
    private final JButton btnBouger  ;
    private final JButton btnAssecher;
    private final JButton btnAutreAction;
    private final JButton btnTerminerTour;
    private JTextField position;
    private VueGrille vueGrille;
   
   
   
    
    public VueAventurier(String nomJoueur, String nomAventurier, Color couleur){

        
        //le titre = nom du joueur 
        this.setLayout(new BorderLayout());

        this.setBackground(new Color(230, 230, 230));
        this.setBorder(BorderFactory.createLineBorder(couleur, 2)) ;

        // =================================================================================
        // NORD : le titre = nom de l'aventurier sur la couleurActive du pion

        this.panelAventurier = new JPanel();
        panelAventurier.setBackground(couleur);
        panelAventurier.add(new JLabel(nomAventurier,SwingConstants.CENTER ));
        this.add(panelAventurier, BorderLayout.NORTH);
   
        // =================================================================================
        /*/ CENTRE : 1 ligne pour position courante
        this.panelCentre = new JPanel(new BorderLayout());
        this.panelCentre.setOpaque(false);
        this.panelCentre.setBorder(new MatteBorder(0, 0, 2, 0, couleur));
        this.add(this.panelCentre, BorderLayout.CENTER);
        
       //
        vueGrille = new VueGrille(new Grille());
        panelCentre.add(vueGrille,BorderLayout.CENTER);
        
        panelCentre.add(new JLabel ("Position",SwingConstants.CENTER), BorderLayout.NORTH);
        //position = new  JTextField(30); 
        //position.setHorizontalAlignment(CENTER);
        //panelCentre.add(position);
        */

        // =================================================================================
        // SUD : les boutons
        this.panelBoutons = new JPanel(new GridLayout(2,2));
        this.panelBoutons.setOpaque(false);
        this.add(this.panelBoutons, BorderLayout.CENTER);

        this.btnBouger = new JButton("Bouger") ;
        this.btnAssecher = new JButton( "Assecher");
        this.btnAutreAction = new JButton("AutreAction") ;
        this.btnTerminerTour = new JButton("Terminer Tour") ;
        
        this.panelBoutons.add(btnBouger);
        this.panelBoutons.add(btnAssecher);
        this.panelBoutons.add(btnAutreAction);
        this.panelBoutons.add(btnTerminerTour);

    } 
    
    public void setPosition(String pos) {
        this.position.setText(pos);
    }
    
     public JButton getBtnAutreAction() {
        return btnAutreAction;
    }
    
    public String getPosition() {
        return position.getText();
    }

    public JButton getBtnBouger() {
        return btnBouger;
    }
    
    public JButton getBtnAssecher() {
        return btnAssecher;
    }

    public JButton getBtnTerminerTour() {
        return btnTerminerTour;
    }
 
}

 

