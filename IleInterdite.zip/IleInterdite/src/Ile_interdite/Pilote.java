package Ile_interdite;

public class Pilote extends Aventurier {
	private boolean pouvoirUtilisé = false;

	public void deplacementPossible(Grille g) {
		throw new UnsupportedOperationException();
	}
}