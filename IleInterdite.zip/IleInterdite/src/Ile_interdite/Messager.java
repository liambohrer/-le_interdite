package Ile_interdite;
public class Messager extends Aventurier {
}