/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ile_interdite;

/**
 *
 * @author bohrerl
 */
public class Tuile {
    
    private String nom;
    private Etat etat;
    private int x;
    private int y;

    public Tuile(String nom) {
        this.setNom(nom);
        this.etat= Etat.Emergé;
        
    }
    
    public Tuile(String nom, Etat etat){
        
        this(nom);
        this.setEtat(etat);
        
    }
    

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setEtat(Etat etat) {
        this.etat = etat;
    }
    
    public void setX(int x) {
        this.x = x;
    }
    
    public void setY(int y) {
        this.y = y;
    }

    public String getNom() {
        return nom;
    }

    public Etat getEtat() {
        return etat;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    public String getInfo(){
        return ( this.getNom() +" (" + this.getX()+","+this.getY()+") " + this.getEtat());
    }
    
    
}
