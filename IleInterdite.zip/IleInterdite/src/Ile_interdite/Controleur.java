/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ile_interdite;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author bohrerl
 */
public class Controleur{
    private static Grille grille;
    private VueAventurier vueAventurier;
    private VueGrille vueGrille;
    /**
     * @param args the command line arguments
     */
     public Controleur(){
         this.grille = new Grille();
         afficherJeu();
         
     }
     
     public void afficherJeu(){
         JFrame window = new JFrame();
        window.setSize(800, 600);
        window.setTitle("hey");
        JPanel panel = new JPanel(new BorderLayout());
        
        vueGrille = new VueGrille(grille);
        vueAventurier = new VueAventurier("hey", "Aventurier", Color.blue);
        panel.add(vueGrille,BorderLayout.CENTER);
        panel.add(vueAventurier,BorderLayout.SOUTH);
        window.add(panel);
        window.setVisible(true);
     }
     
     
    public static void main(String[] args) {
        // TODO code application logic here
    new Controleur();
    VueTuile vueTuile = new VueTuile(new Tuile("La Bonne Ecriture"));
        System.out.println(vueTuile.getNomImage());
    }
    
}

