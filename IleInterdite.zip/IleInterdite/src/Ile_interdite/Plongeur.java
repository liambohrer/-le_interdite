package Ile_interdite;
public class Plongeur extends Aventurier {

	public void deplacementPossible(Grille g) {
		throw new UnsupportedOperationException();
	}
}